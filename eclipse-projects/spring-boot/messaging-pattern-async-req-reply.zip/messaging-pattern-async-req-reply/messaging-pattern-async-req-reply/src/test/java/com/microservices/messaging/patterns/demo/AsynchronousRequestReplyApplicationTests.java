package com.microservices.messaging.patterns.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsynchronousRequestReplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
