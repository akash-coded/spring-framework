package com.microservices.messaging.patterns.demo.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.messaging.patterns.demo.service.AsyncService;

@RestController
public class TestController {
	
	private final AsyncService asyncService;
	
	public TestController(AsyncService asyncService) {
		this.asyncService = asyncService;
	}
	
	@GetMapping("/test")
	public ResponseEntity<String> testAsync() throws ExecutionException, InterruptedException {
		CompletableFuture<String> posts = asyncService.getPosts();
		CompletableFuture<String> comments = asyncService.getComments();
		
		// Wait until they are all done
		CompletableFuture.allOf(posts, comments).join();
		
		// Combine the results
		String combined = "Posts: " + posts.get() + "\n\nComments: " + comments.get();
		
		return ResponseEntity.ok(combined);
	}
}
