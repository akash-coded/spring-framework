package com.microservices.messaging.patterns.demo.service;

import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class AsyncService {

	private final WebClient webClient;
	
	public AsyncService(WebClient.Builder webClientBuilder) {
		this.webClient = webClientBuilder.baseUrl("https://jsonplaceholder.typicode.com").build();
	}
	
	@Async
	public CompletableFuture<String> getPosts() {
		String posts = this.webClient.get()
				.uri("/posts")
				.retrieve()
				.bodyToMono(String.class)
				.block();
		
		return CompletableFuture.completedFuture(posts);
	}
	
	@Async
	public CompletableFuture<String> getComments() {
		String comments = this.webClient.get()
				.uri("/comments")
				.retrieve()
				.bodyToMono(String.class)
				.block();
		
		return CompletableFuture.completedFuture(comments);
	}
	
}
