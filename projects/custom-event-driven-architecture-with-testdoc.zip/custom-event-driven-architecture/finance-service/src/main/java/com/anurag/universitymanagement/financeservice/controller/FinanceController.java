package com.anurag.universitymanagement.financeservice.controller;

import com.anurag.universitymanagement.financeservice.entity.Tuition;
import com.anurag.universitymanagement.financeservice.service.TuitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tuition")
public class FinanceController {
    @Autowired
    private TuitionService service;

    @GetMapping("/{id}")
    public ResponseEntity<Tuition> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<Tuition> saveProduct(@RequestBody Tuition tuition) {
        return ResponseEntity.ok(service.saveProduct(tuition));
    }
}
