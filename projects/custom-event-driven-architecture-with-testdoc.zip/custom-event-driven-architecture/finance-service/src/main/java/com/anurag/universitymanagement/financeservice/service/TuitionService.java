package com.anurag.universitymanagement.financeservice.service;

import com.anurag.universitymanagement.financeservice.entity.Tuition;
import com.anurag.universitymanagement.financeservice.repository.TuitionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TuitionService {
    @Autowired
    private TuitionRepository tuitionRepository;

    public Tuition findById(Long id) {
        return tuitionRepository.findById(id).orElse(null);
    }

    public Tuition saveProduct(Tuition tuition){
        return tuitionRepository.save(tuition);
    }

    public Tuition findByCourseId(String courseId) {
        return tuitionRepository.findByCourseId(courseId);
    }
}
