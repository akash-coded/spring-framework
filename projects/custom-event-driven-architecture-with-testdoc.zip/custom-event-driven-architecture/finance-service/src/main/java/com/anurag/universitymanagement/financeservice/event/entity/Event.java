package com.anurag.universitymanagement.financeservice.event.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Builder
@Data
@Table(name = "Event")
@NoArgsConstructor
@AllArgsConstructor
public class Event implements Comparable<Event>{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String type;
    private String status;
    private String message;
    private Date eventDate;
    private String serviceName;

    @Override
    public int compareTo(Event o) {
        return getEventDate().compareTo(o.getEventDate());
    }
}