package com.anurag.universitymanagement.financeservice.repository;

import com.anurag.universitymanagement.financeservice.entity.Tuition;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TuitionRepository extends JpaRepository<Tuition, Long> {
    Tuition findByCourseId(String courseId);
}
