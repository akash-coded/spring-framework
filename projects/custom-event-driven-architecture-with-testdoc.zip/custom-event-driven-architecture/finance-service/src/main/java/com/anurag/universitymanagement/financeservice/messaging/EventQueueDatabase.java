package com.anurag.universitymanagement.financeservice.messaging;


import com.anurag.universitymanagement.financeservice.entity.Tuition;
import com.anurag.universitymanagement.financeservice.event.entity.Event;
import com.anurag.universitymanagement.financeservice.event.repository.EventRepository;
import com.anurag.universitymanagement.financeservice.service.TuitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
@Transactional("eventTransactionManager")
public class EventQueueDatabase {

    @Autowired
    EventRepository eventRepository;
    @Autowired
    TuitionService tuitionService;


    @Scheduled(fixedDelay = 5000)
    public void readEvents() {
        Event event = consume("StudentRegisteredEvent","FinanceService");
        if (event != null) {
            Tuition tuition = tuitionService.findByCourseId(event.getMessage());
            if (tuition != null && tuition.getFeeAmount() < 10000) {
                publish(Event.builder().eventDate(new Date()).message(event.getMessage()).type("ScholarshipAwardedEvent").build());
            }
            markAsProcessed(event);
            System.out.println(event.getMessage());
        }

    }

    public void publish(Event event) {
        // Insert the event into the database's event_queue table with status 'NEW'
        event.setStatus("NEW");
        eventRepository.save(event);
    }

    public Event consume(String type, String serviceName) {
        List<Event> eventList = eventRepository.findByStatusAndTypeAndServiceName("NEW", type, serviceName);
        Collections.sort(eventList);
        if (!eventList.isEmpty()) {
            Event event = eventList.get(0);
            event.setStatus("IN_PROCESS");
            eventRepository.save(event);
            return event;
        }
        return null;
        // Fetch the oldest event with status 'NEW' or where service_name matches the given serviceName
        // Update its status to 'IN_PROCESS'
        // Return the fetched event
    }

    public void markAsProcessed(Event event) {
        event.setStatus("PROCESSED");
        eventRepository.save(event);
        // Update the event's status in the database to 'PROCESSED'
    }
}