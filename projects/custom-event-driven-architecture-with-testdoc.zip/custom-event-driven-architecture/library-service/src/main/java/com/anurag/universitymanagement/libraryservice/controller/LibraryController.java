package com.anurag.universitymanagement.libraryservice.controller;

import com.anurag.universitymanagement.libraryservice.entity.CourseMaterial;
import com.anurag.universitymanagement.libraryservice.service.CourseMaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/coursematerial")
public class LibraryController {
    @Autowired
    private CourseMaterialService service;

    @GetMapping("/{id}")
    public ResponseEntity<CourseMaterial> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<CourseMaterial> saveProduct(@RequestBody CourseMaterial tuition) {
        return ResponseEntity.ok(service.saveProduct(tuition));
    }
}
