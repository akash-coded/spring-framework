package com.anurag.universitymanagement.libraryservice.service;

import com.anurag.universitymanagement.libraryservice.entity.CourseMaterial;
import com.anurag.universitymanagement.libraryservice.repository.CourseMaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseMaterialService {
    @Autowired
    private CourseMaterialRepository repository;

    public CourseMaterial findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public CourseMaterial findByCourseId(String id) {
        return repository.findByCourseId(id);
    }

    public CourseMaterial saveProduct(CourseMaterial entity){
        return repository.save(entity);
    }
}
