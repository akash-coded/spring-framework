package com.anurag.universitymanagement.libraryservice.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "CourseMaterial")
//Create table CourseMaterial(id BIGINT auto_increment PRIMARY KEY, courseid varchar2(255),materialName varchar2(255),inStock varchar2(1));
public class CourseMaterial {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String courseId;
    private String materialName;
    private Character inStock;
}