package com.anurag.universitymanagement.libraryservice.repository;

import com.anurag.universitymanagement.libraryservice.entity.CourseMaterial;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CourseMaterialRepository extends JpaRepository<CourseMaterial, Long> {
    CourseMaterial findByCourseId(String courseId);
}
