package com.anurag.universitymanagement.libraryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
