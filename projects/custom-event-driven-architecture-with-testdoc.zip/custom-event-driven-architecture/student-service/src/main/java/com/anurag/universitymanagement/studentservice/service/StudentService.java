package com.anurag.universitymanagement.studentservice.service;

import com.anurag.universitymanagement.studentservice.event.entity.Event;
import com.anurag.universitymanagement.studentservice.messaging.EventQueueDatabase;
import com.anurag.universitymanagement.studentservice.student.entity.Student;
import com.anurag.universitymanagement.studentservice.student.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@Transactional("studentTransactionManager")
public class StudentService {
    @Autowired
    private StudentRepository repository;

    @Autowired
    private EventQueueDatabase eventQueueDatabase;

    public Student findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Student saveStudent(Student entity){
        eventQueueDatabase.publish(Event.builder().type("StudentRegisteredEvent").serviceName("LibraryService").message(entity.getCourseId()).eventDate(new Date()).build());
        eventQueueDatabase.publish(Event.builder().type("StudentRegisteredEvent").serviceName("FinanceService").message(entity.getCourseId()).eventDate(new Date()).build());
        return repository.save(entity);
    }
}
