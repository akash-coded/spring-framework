package com.anurag.universitymanagement.studentservice.event.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
//Create table event(id BIGINT auto_increment PRIMARY KEY, type varchar2(255),status varchar2(255),message varchar2(255),eventDate Date);
@Entity
@Builder
@Data
@Table(name = "Event")
@NoArgsConstructor
@AllArgsConstructor
public class Event implements Comparable<Event>{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String type;
    private String status;
    private String message;
    private Date eventDate;
    private String serviceName;

    @Override
    public int compareTo(Event o) {
        return getEventDate().compareTo(o.getEventDate());
    }
}