package com.anurag.universitymanagement.studentservice.student.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Student")
//Create table Student(id BIGINT auto_increment PRIMARY KEY, courseid varchar2(255),name varchar2(255));
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String courseId;
    private String name;
}