package com.anurag.universitymanagement.studentservice.messaging;

import com.anurag.universitymanagement.studentservice.event.entity.Event;
import com.anurag.universitymanagement.studentservice.event.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;

@Service
@Transactional("eventTransactionManager")
public class EventQueueDatabase {

    @Autowired
    EventRepository eventRepository;

    public void publish(Event event) {
        // Insert the event into the database's event_queue table with status 'NEW'
        event.setStatus("NEW");
        eventRepository.save(event);
    }

    public Event consume(String serviceName) {
        List<Event> eventList = eventRepository.findByStatus("NEW");
        Collections.sort(eventList);
        if (!eventList.isEmpty()) {
            Event event = eventList.get(0);
            event.setStatus("IN_PROCESS");
            eventRepository.save(event);
            return event;
        }
        return null;
        // Fetch the oldest event with status 'NEW' or where service_name matches the given serviceName
        // Update its status to 'IN_PROCESS'
        // Return the fetched event
    }

    public void markAsProcessed(Event event) {
        event.setStatus("PROCESSED");
        eventRepository.save(event);
        // Update the event's status in the database to 'PROCESSED'
    }
}