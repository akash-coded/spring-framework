package com.anurag.universitymanagement.studentservice.controller;

import com.anurag.universitymanagement.studentservice.student.entity.Student;
import com.anurag.universitymanagement.studentservice.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class StudentController {
    @Autowired
    private StudentService service;

    @GetMapping("/{id}")
    public ResponseEntity<Student> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    public ResponseEntity<Student> saveProduct(@RequestBody Student tuition) {
        return ResponseEntity.ok(service.saveStudent(tuition));
    }
}
