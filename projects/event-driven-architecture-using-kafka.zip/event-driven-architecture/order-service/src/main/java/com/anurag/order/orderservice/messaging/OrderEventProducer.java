package com.anurag.order.orderservice.messaging;

public class OrderEventProducer {
}
