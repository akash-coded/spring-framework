package com.anurag.inventory.inventoryservice.repository;

import com.anurag.inventory.inventoryservice.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {}
